﻿//using System;

namespace _06_Beep
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.Beep();
            /*Console.Beep(500, 2000);
            Console.WriteLine("Hello World!");*/
            System.Console.Beep();
            System.Console.WriteLine("qwerty");
        }
    }
}
