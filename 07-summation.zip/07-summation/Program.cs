﻿using System;

namespace _07_summation
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int a = 5, b = 10;
            int result = a + b;
            Console.WriteLine(result);
            Console.ReadKey();*/


            /* int a, b;
             string result;

             Console.WriteLine("Enter a number here :");
             result = Console.ReadLine();
             a = int.Parse(result);

             Console.WriteLine("Enter a number here :");
             result = Console.ReadLine();
             b = int.Parse(result);

             Console.WriteLine("answer " + (a + b));
             Console.WriteLine("press any key to Exit ...");
             Console.ReadKey(); */


            /* int a, b;
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            int result = a + b;
            Console.WriteLine(result);
            Console.ReadKey(); */


            /*float c = 2.5f, d = -5.667f;
            float x = c * d;
            Console.WriteLine(x);
            Console.ReadKey(); */

            
            //tartibe fname lname va int age mohem ast
            string fname, lname;
            string name;
            fname = (Console.ReadLine());
            lname = (Console.ReadLine());
            int age = int.Parse(Console.ReadLine());
            name = "Your name is "+ fname +" "+ lname+" "+ age.ToString();
            Console.WriteLine(name);
            Console.ReadKey();
            
        }
    }
}
