﻿using System;

namespace _10_Course
{
    class Program
    {
        static void Main(string[] args)
        {
            double Anum = double.Parse(Console.ReadLine());
            int anum = int.Parse(Console.ReadLine());

            double Bnum = double.Parse(Console.ReadLine());
            int bnum = int.Parse(Console.ReadLine());

            double Cnum = double.Parse(Console.ReadLine());
            int cnum = int.Parse(Console.ReadLine());


            double average = ((anum * Anum) + (bnum * Bnum) + (cnum * Cnum)) / (anum + bnum + cnum);
            Console.WriteLine(average);
        }
    }
}
