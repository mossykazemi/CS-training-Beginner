﻿using System;

namespace Conditions
{
    class Program
    {
        static void Main(string[] args)
        {
            string strMessage = "";
            Console.WriteLine("please enter a number:");
            int n = int.Parse(Console.ReadLine());
            switch (n)
            {
                case 1:
                    strMessage = "The Number is one";
                    break;
                case 2:
                    strMessage = "The Number is two";
                    break;
                default:
                    strMessage = "unknown!";
                    break;
            }
            Console.WriteLine(strMessage);
        }
    }
}
