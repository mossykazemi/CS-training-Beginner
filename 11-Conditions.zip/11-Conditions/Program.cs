﻿using System;

namespace _11_Conditions
{
    class Program2
    {
        static void Main(string[] args)
        {
            int age = Convert.ToInt32(Console.ReadLine());
            if (age==18)
            {
                Console.WriteLine("Hello qotameh!");
            }else
            {
                Console.WriteLine("Come back soon!");
            }
            Console.ReadKey();
        }
    }
}
