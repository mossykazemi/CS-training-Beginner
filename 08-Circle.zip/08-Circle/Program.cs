﻿using System;

namespace _08_Circle
{
    class Program
    {
        static void Main(string[] args)
        {
            double r;
            r = double.Parse(Console.ReadLine());
            Console.WriteLine("Result is:  "+(r * r) * 3.14);
            Console.ReadKey();
        }
    }
}
