﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismSample
{
    class CommisiionEmployee:Employee
    {
        private double grosssales;
        private double commissionrate;
        public double GroossSales
        {
            set
            {
                grosssales = value;
            }
            get
            {
                return grosssales;
            }
        }
        public double CommissionRate
        {
            set
            {
                commissionrate = value;
            }
            get
            {
                return commissionrate;
            }
        }
        public CommisiionEmployee(string fn,string ln,string ssn,double rate, double sales):base(fn,ln,ssn)
        {
            GroossSales = sales;
            CommissionRate = rate;
        }
        public override double Earning()
        {
            return GroossSales * CommissionRate;
        }
        public override string ToString()
        {
            return "\nCommission Employee: " + base.ToString() + "\nGross Sale: " + GroossSales + "\nCommission rate: " + CommissionRate;
        }
    }
}
