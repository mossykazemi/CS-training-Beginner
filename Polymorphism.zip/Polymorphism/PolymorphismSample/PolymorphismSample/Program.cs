﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismSample
{
    class Program
    {
        static void Main(string[] args)
        {
            SalariedEmployee s = new SalariedEmployee("sadegh", "Naderi", "3265987", 2000000);
            HourlyEmployee h = new HourlyEmployee("Akbar", "Akbari", "2154871", 50, 6500);
            CommisiionEmployee c = new CommisiionEmployee("Asghar", "Asghari", "25143698", 0.4, 3000000);
            BasePluseCommissionEmployee b = new BasePluseCommissionEmployee("Soghra", "Soghraee", "8754213", 0.4,3000000,2000000);
            //Console.WriteLine(s.ToString()+"\nPayment:"+s.Earning());
            //Console.WriteLine(h.ToString() + "\nPayment:" + h.Earning());
            //Console.WriteLine(c.ToString() + "\nPayment:" + c.Earning());
            //Console.WriteLine(b.ToString() + "\nPayment:" + b.Earning());
            //Employee[] list = new Employee[4];
            //list[0] = s;
            //list[1] = h;
            //list[2] = c;
            //list[3] = b;
            //foreach(Employee x in list)
            //{
            //    Console.WriteLine(x.ToString()+"\nPayment: "+x.Earning());
            //}
            Employee[] list = new Employee[4];
            list[0] = s;
            list[1] = h;
            list[2] = c;
            list[3] = b;
            foreach (Employee x in list)
            {
                if(x is BasePluseCommissionEmployee)
                {
                    BasePluseCommissionEmployee b1 = (BasePluseCommissionEmployee)x;
                    b1.BaseSalary *= 1.10;
                }
                Console.WriteLine(x.ToString() + "\nPayment: " + x.Earning());
            }
            Console.ReadKey();

        }
    }
}
