﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismSample
{
    class BasePluseCommissionEmployee:CommisiionEmployee
    {
        private double baseslary;
        public double BaseSalary
        {
            set
            {
                baseslary = value;
            }
            get
            {
                return baseslary;
            }
        }
        public BasePluseCommissionEmployee(string fn, string ln, string ssn, double rate, double sales,double bsalary):base(fn,ln,ssn,rate,sales)
        {
            BaseSalary = bsalary;
        }
        public override double Earning()
        {
            return BaseSalary + base.Earning();
        }
        public override string ToString()
        {
            return "\n\nBase Salary: " + base.ToString() + "\nBase Salary: " + BaseSalary;
        }
    }
}
