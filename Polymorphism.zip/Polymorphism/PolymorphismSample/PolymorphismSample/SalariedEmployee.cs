﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismSample
{
    class SalariedEmployee:Employee
    {
        private double weeklySalary;
        public double WeeklySalary
        {
            set
            {
                weeklySalary = value;
            }
            get
            {
                return weeklySalary;
            }
        }
        public SalariedEmployee(string fn,string ln,string ssn,double salary):base(fn,ln,ssn)
        {
            WeeklySalary = salary;
        }
        public override double Earning()
        {
            return WeeklySalary;
        }
        public override string ToString()
        {
            return "\n\nSalareied Employee: " + base.ToString() + "Weekly salary: " + WeeklySalary;
        }
    }

}
