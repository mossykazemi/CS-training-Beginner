﻿using System;

namespace _15_min
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, min;
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            c = int.Parse(Console.ReadLine());

                min = a;
            if (b < min)
                min = b;
            if (c < min)
                min = c;
            Console.WriteLine(min);
        }
    }
}
