﻿using System;

namespace farde_3_raghami
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting odd numbers from 0 to 1000 :");
            for (int i = 1; i <= 1000; i = i += 2)
            {

                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
    }
}
