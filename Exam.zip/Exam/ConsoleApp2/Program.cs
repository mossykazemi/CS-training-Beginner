﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting frrom 100 to 0 with While :");
            int i = 100;
            while (i >= 0)
            {
                Console.WriteLine(i);
                --i;
            }
            Console.ReadKey();
        }
    }
}
