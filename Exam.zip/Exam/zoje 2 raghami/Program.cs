﻿using System;

namespace zoje_2_raghami
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting even numbers from 0 to 100 :");
            for (int i = 0; i <= 100; ++i)
            {
                if (i % 2 == 0)
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
    }
}
