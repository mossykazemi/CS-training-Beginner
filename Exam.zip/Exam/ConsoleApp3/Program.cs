﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting odd numbers from 0 to 100 :");
            for (int i = 1; i <= 100; i = i += 2)
            {
               
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
        
    }
}
