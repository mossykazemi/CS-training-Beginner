﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting frrom 0 to 100 :");
            for (int i = 0; i <= 100; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
