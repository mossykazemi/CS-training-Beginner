﻿using System;

namespace zoje_3_raghami
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Counting even numbers from 0 to 1000 :");
            for (int i = 0; i <= 999; i+=2)
            {
                    Console.Write(i+"\t");
            }
            Console.ReadKey();
        }
    }
}
