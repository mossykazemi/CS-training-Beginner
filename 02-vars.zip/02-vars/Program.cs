﻿using System;

namespace _02_vars
{
    class Program
    {
        static void Main(string[] args)
        {
            // \n \t
            Console.Write("Hello World!\t");
            Console.WriteLine("Hello World!");
            Console.WriteLine("we can print a \\ ");
            Console.WriteLine("C:\\Users\\Public\\Music\\Sample Music\\Kalimba.mp3");
            Console.WriteLine("I said, \" Motivate your self! \" ");
            Console.WriteLine("The programmer\'s guide");
            Console.WriteLine("Mitten\rk");
            Console.WriteLine(@"we can print a \ ");
            Console.WriteLine(@"C:\Users\Public\Music\Sample Music\Kalimba.mp3");
            Console.WriteLine(@"I want to have a cat/dog as a Birthday present.");
            Console.WriteLine(@"I said, ""Motivate your self!"" ");
            Console.WriteLine(@"C# is a great programming language
                           it allows you to creat diffrent
                                    kinds of applications");
            Console.ReadKey();

        }
    }
}
