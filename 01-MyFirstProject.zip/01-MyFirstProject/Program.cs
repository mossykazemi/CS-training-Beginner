﻿using System;

namespace MyFirstProject
{
    class Program
    {
        static void Main(string[] args)
        {
            string var1;
            var1 = "Mostafa Kazemi";
            //case sensitive
            //compiler
            Console.WriteLine(var1);
            
        }
    }
}
