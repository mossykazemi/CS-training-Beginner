﻿using System;

namespace CsharpTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            string strMessage;
            strMessage = "Welcome from program!";
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine(strMessage);
            Console.ReadKey();
        }
    }
}
