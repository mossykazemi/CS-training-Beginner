﻿using System;

namespace _13_conditions
{
    class Program
    {
        static void Main(string[] args)
        {
            string DaysOfWeek = "";
            Console.WriteLine("please enter a number:");
            int n = int.Parse(Console.ReadLine());
            switch (n)
            {
                case 1:

                case 2:

                case 3:

                case 4:

                case 5:
                    DaysOfWeek = "Working Day";
                    break;
                case 6:
                case 7:
                    DaysOfWeek = "Weekend";
                    break;
                default:
                    DaysOfWeek = "unknown!";
                    break;
            }
            Console.WriteLine(DaysOfWeek);
        }
    }
}

