﻿using System;

namespace _14_max
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, max;
            a=int.Parse(Console.ReadLine());
            b=int.Parse(Console.ReadLine());
            c=int.Parse(Console.ReadLine());

            max = a;
            if (b > max)
                max = b;
            if (c > max)
                max = c;
            Console.WriteLine(max);
           
        }
    }
}
