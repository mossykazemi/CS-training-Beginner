﻿using System;

namespace _09_Function
{
    class Program
    {
        static void Main(string[] args)
        {
            
            // olaviat ba parantez hast 
            int i;
            i = 12 %5;
            float j = (float)12 / 5;
            Console.WriteLine("{0} , {1}",j,i);
            //used PlaceHolder up there
            

            
        }
    }
}
