﻿using System;

namespace _03_vars
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare variables
            int num;
            num = -6;
            string message;
            message = "Mossy Yankee";
            char ch = 'm';
            double num1;
            num1 = 1.5;
            bool boolVar;
            boolVar = true;
            //Place Holder {0}
            //Console.WriteLine("num is :{0} \n and message is :{1} ", num,message);
            Console.WriteLine("temp is on :{0} here \t and {1} is getting cold so \n i wish temp was on {2}",num,message,num1);
            Console.ReadKey();
        }
    }
}
