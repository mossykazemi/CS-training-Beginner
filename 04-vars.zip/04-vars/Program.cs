﻿using System;

namespace _04_vars
{
    class Program
    {
        static void Main(string[] args)
        {
            // Data type Convertation


            /*sbyte number = 5;
            int number1;
            number1 = number;
            Console.WriteLine("number1: {0}", number1);
            Console.ReadLine();*/


            /* byte number;
             number = 250;
             int number1;
             number1 =Convert.ToInt32( number);
             Console.WriteLine("the num is :{0}", number1);
             Console.ReadKey(); */


            byte number;
            number = 250;
            string strNumber = "497";
            string strResult = strNumber + number.ToString();
            Console.WriteLine(strResult);
            Console.ReadKey();

        }
    }
}
